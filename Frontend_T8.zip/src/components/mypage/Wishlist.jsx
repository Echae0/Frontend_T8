export default function Wishlist() {
  return (
    <div>
      <h2 style={{ marginBottom: '16px' }}>찜 목록</h2>
      <p>찜한 항목들을 모아볼 수 있습니다.</p>
    </div>
  );
}