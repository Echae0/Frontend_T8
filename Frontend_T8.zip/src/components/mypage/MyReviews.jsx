export default function MyReviews() {
  return (
    <div>
      <h2 style={{ marginBottom: '16px' }}>내 리뷰</h2>
      <p>작성한 리뷰 목록을 확인할 수 있습니다.</p>
    </div>
  );
}