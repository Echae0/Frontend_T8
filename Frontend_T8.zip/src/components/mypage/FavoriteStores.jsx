export default function FavoriteStores() {
  return (
    <div>
      <h2 style={{ marginBottom: '16px' }}>최근 관심있는 가게</h2>
      <p>최근에 관심을 가진 가게들을 보여줍니다.</p>
    </div>
  );
}